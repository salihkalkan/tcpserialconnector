package seriport;

import java.io.File;
import java.io.IOException;

import net.sf.jni4net.Bridge;

public class hello {

	public static void main(String[] args) throws IOException, InterruptedException {
		Bridge.setVerbose(true);
	    Bridge.init();
	    
	    File proxyAssemblyFile = new File("deneme.j4n.dll");
	    Bridge.LoadAndRegisterAssemblyFrom(proxyAssemblyFile);
	    
	    aselsan.io.SerialPort.Start("COM12", 38400);
	    
	    aselsan.io.SerialPort.Write(new byte[] {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15});
	    byte[] denemeeee = aselsan.io.SerialPort.Read();
	    System.out.println(denemeeee.length);
	    Thread.sleep(100000);
	}

}
