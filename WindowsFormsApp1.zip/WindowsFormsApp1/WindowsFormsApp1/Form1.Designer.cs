﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.senderBaudRateCombobox = new System.Windows.Forms.ComboBox();
            this.senderDataBitsCombobox = new System.Windows.Forms.ComboBox();
            this.senderStopBitsCombobox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.senderParityCombobox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.senderSerialPortCombobox = new System.Windows.Forms.ComboBox();
            this.startStopSendingButton = new System.Windows.Forms.Button();
            this.sendTextBox = new System.Windows.Forms.RichTextBox();
            this.sendPeriodicallyButton = new System.Windows.Forms.Button();
            this.receivedDataDataGridView = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.senddataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.receivedDataDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.senddataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // senderBaudRateCombobox
            // 
            this.senderBaudRateCombobox.FormattingEnabled = true;
            this.senderBaudRateCombobox.Location = new System.Drawing.Point(181, 94);
            this.senderBaudRateCombobox.Name = "senderBaudRateCombobox";
            this.senderBaudRateCombobox.Size = new System.Drawing.Size(190, 23);
            this.senderBaudRateCombobox.TabIndex = 43;
            this.senderBaudRateCombobox.SelectedIndexChanged += new System.EventHandler(this.senderBaudRateCombobox_SelectedIndexChanged);
            // 
            // senderDataBitsCombobox
            // 
            this.senderDataBitsCombobox.FormattingEnabled = true;
            this.senderDataBitsCombobox.Location = new System.Drawing.Point(181, 189);
            this.senderDataBitsCombobox.Name = "senderDataBitsCombobox";
            this.senderDataBitsCombobox.Size = new System.Drawing.Size(190, 23);
            this.senderDataBitsCombobox.TabIndex = 42;
            this.senderDataBitsCombobox.SelectedIndexChanged += new System.EventHandler(this.senderDataBitsCombobox_SelectedIndexChanged);
            // 
            // senderStopBitsCombobox
            // 
            this.senderStopBitsCombobox.FormattingEnabled = true;
            this.senderStopBitsCombobox.Location = new System.Drawing.Point(181, 239);
            this.senderStopBitsCombobox.Name = "senderStopBitsCombobox";
            this.senderStopBitsCombobox.Size = new System.Drawing.Size(190, 23);
            this.senderStopBitsCombobox.TabIndex = 41;
            this.senderStopBitsCombobox.SelectedIndexChanged += new System.EventHandler(this.senderStopBitsCombobox_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(56, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 15);
            this.label9.TabIndex = 40;
            this.label9.Text = "Port Name :";
            // 
            // senderParityCombobox
            // 
            this.senderParityCombobox.FormattingEnabled = true;
            this.senderParityCombobox.Location = new System.Drawing.Point(181, 145);
            this.senderParityCombobox.Name = "senderParityCombobox";
            this.senderParityCombobox.Size = new System.Drawing.Size(190, 23);
            this.senderParityCombobox.TabIndex = 39;
            this.senderParityCombobox.SelectedIndexChanged += new System.EventHandler(this.senderParityCombobox_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 242);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 38;
            this.label4.Text = "Stop Bits :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 15);
            this.label3.TabIndex = 37;
            this.label3.Text = "Data Bits :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 36;
            this.label2.Text = "Parity :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 15);
            this.label1.TabIndex = 35;
            this.label1.Text = "Baud Rate :";
            // 
            // senderSerialPortCombobox
            // 
            this.senderSerialPortCombobox.FormattingEnabled = true;
            this.senderSerialPortCombobox.Location = new System.Drawing.Point(181, 48);
            this.senderSerialPortCombobox.Name = "senderSerialPortCombobox";
            this.senderSerialPortCombobox.Size = new System.Drawing.Size(190, 23);
            this.senderSerialPortCombobox.TabIndex = 34;
            this.senderSerialPortCombobox.SelectedIndexChanged += new System.EventHandler(this.senderSerialPortCombobox_SelectedIndexChanged);
            // 
            // startStopSendingButton
            // 
            this.startStopSendingButton.Location = new System.Drawing.Point(630, 226);
            this.startStopSendingButton.Name = "startStopSendingButton";
            this.startStopSendingButton.Size = new System.Drawing.Size(148, 31);
            this.startStopSendingButton.TabIndex = 44;
            this.startStopSendingButton.Text = "Send";
            this.startStopSendingButton.UseVisualStyleBackColor = true;
            this.startStopSendingButton.Click += new System.EventHandler(this.startStopSendingButton_Click);
            // 
            // sendTextBox
            // 
            this.sendTextBox.Location = new System.Drawing.Point(424, 48);
            this.sendTextBox.Name = "sendTextBox";
            this.sendTextBox.Size = new System.Drawing.Size(354, 164);
            this.sendTextBox.TabIndex = 45;
            this.sendTextBox.Text = "";
            // 
            // sendPeriodicallyButton
            // 
            this.sendPeriodicallyButton.Location = new System.Drawing.Point(424, 226);
            this.sendPeriodicallyButton.Name = "sendPeriodicallyButton";
            this.sendPeriodicallyButton.Size = new System.Drawing.Size(148, 31);
            this.sendPeriodicallyButton.TabIndex = 48;
            this.sendPeriodicallyButton.Text = "Send Periodically";
            this.sendPeriodicallyButton.UseVisualStyleBackColor = true;
            this.sendPeriodicallyButton.Click += new System.EventHandler(this.sendPeriodicallyButton_Click);
            // 
            // receivedDataDataGridView
            // 
            this.receivedDataDataGridView.AllowUserToAddRows = false;
            this.receivedDataDataGridView.AllowUserToDeleteRows = false;
            this.receivedDataDataGridView.AllowUserToOrderColumns = true;
            this.receivedDataDataGridView.AllowUserToResizeColumns = false;
            this.receivedDataDataGridView.AllowUserToResizeRows = false;
            this.receivedDataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.receivedDataDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column1});
            this.receivedDataDataGridView.Location = new System.Drawing.Point(56, 314);
            this.receivedDataDataGridView.Name = "receivedDataDataGridView";
            this.receivedDataDataGridView.RowHeadersVisible = false;
            this.receivedDataDataGridView.RowTemplate.Height = 25;
            this.receivedDataDataGridView.Size = new System.Drawing.Size(467, 179);
            this.receivedDataDataGridView.TabIndex = 49;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Time";
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Content";
            this.Column1.Name = "Column1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 286);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 50;
            this.label6.Text = "Gelen Mesaj";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(550, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 52;
            this.label5.Text = "Giden Mesaj";
            // 
            // senddataGridView
            // 
            this.senddataGridView.AllowUserToAddRows = false;
            this.senddataGridView.AllowUserToDeleteRows = false;
            this.senddataGridView.AllowUserToOrderColumns = true;
            this.senddataGridView.AllowUserToResizeColumns = false;
            this.senddataGridView.AllowUserToResizeRows = false;
            this.senddataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.senddataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.senddataGridView.Location = new System.Drawing.Point(550, 314);
            this.senddataGridView.Name = "senddataGridView";
            this.senddataGridView.RowHeadersVisible = false;
            this.senddataGridView.RowTemplate.Height = 25;
            this.senddataGridView.Size = new System.Drawing.Size(228, 179);
            this.senddataGridView.TabIndex = 51;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "Time";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 520);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.senddataGridView);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.receivedDataDataGridView);
            this.Controls.Add(this.sendPeriodicallyButton);
            this.Controls.Add(this.sendTextBox);
            this.Controls.Add(this.startStopSendingButton);
            this.Controls.Add(this.senderBaudRateCombobox);
            this.Controls.Add(this.senderDataBitsCombobox);
            this.Controls.Add(this.senderStopBitsCombobox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.senderParityCombobox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.senderSerialPortCombobox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.receivedDataDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.senddataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox senderBaudRateCombobox;
        private System.Windows.Forms.ComboBox senderDataBitsCombobox;
        private System.Windows.Forms.ComboBox senderStopBitsCombobox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox senderParityCombobox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox senderSerialPortCombobox;
        private System.Windows.Forms.Button startStopSendingButton;
        private System.Windows.Forms.RichTextBox sendTextBox;
        private System.Windows.Forms.Button sendPeriodicallyButton;
        private System.Windows.Forms.DataGridView receivedDataDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView senddataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    }
}

