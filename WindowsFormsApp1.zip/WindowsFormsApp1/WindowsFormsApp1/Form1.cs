﻿using System;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private SerialPort senderSerialPort;
        private bool isDataSendingPeriodically = false;

        public Form1()
        {
            InitializeComponent();

            senderParityCombobox.DataSource = Enum.GetValues(typeof(Parity));
            senderStopBitsCombobox.DataSource = new string[] { "1", "2", "1.5" };
            senderDataBitsCombobox.DataSource = new string[] { "5", "6", "7", "8" };
            senderBaudRateCombobox.DataSource = new string[] { "110", "300", "600", "1200", "2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200", "128000", "256000" };

            foreach (string serialPortName in SerialPort.GetPortNames())
                senderSerialPortCombobox.Items.Add(serialPortName);
        }

        private void senderSerialPortCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (senderSerialPort != null)
                    senderSerialPort.Close();

                senderSerialPort = new SerialPort(senderSerialPortCombobox.SelectedItem.ToString());
                senderSerialPort.BaudRate = 9600;
                senderSerialPort.ReadTimeout = SerialPort.InfiniteTimeout;

                senderBaudRateCombobox.SelectedItem = senderSerialPort.BaudRate.ToString();
                senderParityCombobox.SelectedItem = senderSerialPort.Parity;
                senderDataBitsCombobox.SelectedItem = senderSerialPort.DataBits.ToString();
                senderStopBitsCombobox.SelectedItem = ConvertStopBitsCombobox(senderSerialPort.StopBits);

                senderSerialPort.Open();

                Task.Run(() =>
                {
                    byte[] receiveBuffer = new byte[128];

                    while (true)
                    {
                        int readByteCount = senderSerialPort.Read(receiveBuffer, 0, 128);
                        DateTime time = DateTime.Now;
                        string timeText = time.Hour.ToString() + ":" + time.Minute.ToString() + ":" + time.Second.ToString() + ":" + time.Millisecond.ToString();
                        string receivedData = string.Join(" ", receiveBuffer.Take(readByteCount).Select(x => x.ToString("X2")));

                        BeginInvoke(new Action(() =>
                        {
                            receivedDataDataGridView.Rows.Add(timeText, receivedData);
                        }));

                        receiveBuffer = new byte[128];
                    }
                });
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string ConvertStopBitsCombobox(StopBits stopBits)
        {
            if (stopBits == StopBits.One)
                return "1";

            else if (stopBits == StopBits.Two)
                return "2";

            else if (stopBits == StopBits.OnePointFive)
                return "1.5";

            return "";
        }

        private StopBits ConvertStopBitsCombobox(string stopBits)
        {
            if (stopBits == "1")
                return StopBits.One;

            else if (stopBits == "2")
                return StopBits.Two;

            else if (stopBits == "1.5")
                return StopBits.OnePointFive;

            return StopBits.None;
        }

        private void senderBaudRateCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (senderSerialPort != null)
                {
                    senderSerialPort.BaudRate = int.Parse(senderBaudRateCombobox.SelectedItem.ToString());
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void senderParityCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (senderSerialPort != null)
                {
                    senderSerialPort.Parity = (Parity)senderParityCombobox.SelectedItem;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void senderDataBitsCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (senderSerialPort != null)
                {
                    senderSerialPort.DataBits = int.Parse(senderDataBitsCombobox.SelectedItem.ToString());
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void senderStopBitsCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (senderSerialPort != null)
                {
                    senderSerialPort.StopBits = ConvertStopBitsCombobox(senderStopBitsCombobox.SelectedItem.ToString());
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Send butonu
        private void startStopSendingButton_Click(object sender, EventArgs e)
        {
            try
            {
                string[] dataString = sendTextBox.Text.Trim().Split(' ');
                byte[] data = new byte[dataString.Length];

                for (int i = 0; i < dataString.Length; i++)
                {
                    data[i] = Convert.ToByte(dataString[i], 16);
                }

                DateTime time = DateTime.Now;
                string timeStr = time.Hour.ToString() + ":" + time.Minute.ToString() + ":" + time.Second.ToString() + ":" + time.Millisecond.ToString();
                senddataGridView.Rows.Add(timeStr);
                senderSerialPort.Write(data, 0, data.Length);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void sendPeriodicallyButton_Click(object sender, EventArgs e)
        {
            if (isDataSendingPeriodically)
            {
                isDataSendingPeriodically = false;
                sendPeriodicallyButton.Text = "Send Periodically";
            }
            else
            {
                isDataSendingPeriodically = true;
                sendPeriodicallyButton.Text = "Stop Sending";

                Task.Run(() =>
                {
                    while (isDataSendingPeriodically)
                    {
                        DateTime start = DateTime.Now;
                        string[] dataString = sendTextBox.Text.Trim().Split(' ');
                        byte[] data = new byte[dataString.Length];

                        for (int i = 0; i < dataString.Length; i++)
                        {
                            data[i] = Convert.ToByte(dataString[i], 16);
                        }

                        string timeStr = start.Hour.ToString() + ":" + start.Minute.ToString() + ":" + start.Second.ToString() + ":" + start.Millisecond.ToString();
                        BeginInvoke(new Action(() =>
                        {
                            senddataGridView.Rows.Add(timeStr);
                        }));

                        senderSerialPort.Write(data, 0, data.Length);
                        DateTime end = DateTime.Now;
                        TimeSpan ts = end - start;
                        Thread.Sleep((int)(1000 - ts.TotalMilliseconds));
                    }
                });
            }
        }
    }
}
